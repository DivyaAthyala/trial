﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Configuration;

namespace ModeApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            getMode();
        }

        private void getMode()
        {
            try { 
            //Properties.Settings.Default.Save();
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.ThreadOptions = PSThreadOptions.UseCurrentThread;
            runspace.Open();
            PowerShell ps = PowerShell.Create();
            ps.Runspace = runspace;
            var testPath= ConfigurationManager.AppSettings["testPath"];
            ps.AddScript(System.IO.File.ReadAllText(testPath));
            ps.Invoke();
            //code for mode retrieval
            var currentMode = runspace.SessionStateProxy.PSVariable.GetValue("Mode");
            mode.Content = currentMode.ToString();
            Properties.Settings.Default.Mode = currentMode.ToString();
            Properties.Settings.Default.Save();
            }
            catch(Exception ex)
            {
                System.IO.File.WriteAllText(@"C:\TEMP\logGet.txt", ex.InnerException.ToString());

            }
        }

        private void changeMode(object sender, RoutedEventArgs e)
        {
            try { 
            var isAdmin = Useful.IsUserAnAdministrator();
            var currentMode = Properties.Settings.Default.Mode;

            if (isAdmin == true)
            {

                Runspace runspace1 = RunspaceFactory.CreateRunspace();
                runspace1.ThreadOptions = PSThreadOptions.UseCurrentThread;
                runspace1.Open();
                PowerShell ps1 = PowerShell.Create();
                ps1.Runspace = runspace1;
                var changePath = ConfigurationManager.AppSettings["changePath"];
                ps1.AddScript(System.IO.File.ReadAllText(changePath));
                ps1.Invoke();
                //code for mode retrieval                  
                MessageBox.Show("You are now changing your system mode settings", " System Mode Update", MessageBoxButton.OK, MessageBoxImage.Information);

            }
            else
                MessageBox.Show("You are now changing your system mode settings", " System Mode Update", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                System.IO.File.WriteAllText(@"C:\TEMP\logChange.txt", ex.InnerException.ToString());

            }

        }
    }
}
