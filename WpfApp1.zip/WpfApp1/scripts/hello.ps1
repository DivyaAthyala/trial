$LogFile="C:\Users\divya.athyala\DRepos\Logs\"+$LogTime+".txt"
"running program">>$logfile
