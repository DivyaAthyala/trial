﻿
Get-Item -Path HKLM:\Software\ACN\rDWPMode | Remove-ItemProperty -Name CurrentrDWPMode -Force