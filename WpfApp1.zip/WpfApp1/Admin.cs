﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace ModeApp
{
    public static class Useful
    {
        [DllImport("shell32.dll", EntryPoint = "IsUserAnAdmin")]
        public static extern bool IsUserAnAdministrator();
    }

}

